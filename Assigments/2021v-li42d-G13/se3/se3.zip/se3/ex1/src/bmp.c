#include <stdio.h>
#include <string.h>

#include "bmp.h"

int main(int argc, char * argv[]) {
	if (argc < 2 || argc > 3 || strlen(argv[1])  < 5 ||
		strcmp(argv[1] + (strlen(argv[1]) - 4), ".bmp") != 0)
	{
		fprintf(stderr, "use: %s {filename}.bmp [offset]\n", argv[0]);
		return 1;
	}

	// TO DO

	return 0;
}
